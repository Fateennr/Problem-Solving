#include<iostream>
#include<sstream>

using namespace std;

struct Node
{
    bool endmark;
    Node *next[26];

    Node()
    {
        endmark = false;
        for(int i=0;i<26;i++)
        {
            next[i] = NULL;
        }
    }
};

Node *root = NULL;

void insert(string str, int len)
{
    int idx;
    Node *curr = root;
    for(int i=0;i<len;i++)
    {
        idx = str[i]- 'a'; 
        if(curr->next[idx] == NULL)
        {
            curr->next[idx] = new Node();

        }
        curr = curr->next[idx];
    }
    curr->endmark = true;
}


bool search(string str, int len)
{
    int idx;
    Node *current = root;
    for(int i=0; i<len; i++)
    {
        idx = str[i] - 'a';
        if(current->next[idx] == NULL)
        {
            return false;
        }
        else
        {
            current = current->next[idx];
        }
    }
    return current->endmark;
}

void display(Node *curr, char status[], int level)
{

    if(curr->endmark == true)
    {
        status[level] = '\0';
        cout<<status<<endl;
    }

    for(int i=0;i<26;i++)
    {
        if(curr->next[i] != NULL)
        {
            status[level] = i + 'a';
            display(curr->next[i], status, level+1);
        }
    }
}


int main()
{
    // root =new Node();

    // string inp;
    // getline(cin, inp);
    // inp += " ";
    // // cout<<"gg"<<inp<<endl;

    // while(inp.size() != 0)
    // {
    //     int pos = inp.find(" ");
    //     string sub = inp.substr(0, pos);

    //     insert(sub, sub.size());

    //     inp.erase(0, pos+1);
    //     // cout<<sub<<endl;
    // }
    // char status[100];
    // display(root,status,0);

    // string newinp;
    // getline(cin, newinp);
    // newinp += " ";
    // // cout<<"gg"<<newinp<<endl;

    // while(newinp.size() != 0)
    // {
    //     int pos = newinp.find(" ");
    //     string newsub = newinp.substr(0, pos);

    //     // insert(newsub, newsub.size());

    //     if(search(newsub,newsub.size())) {cout<<"T ";}
    //     else{cout<<"F ";}

    //     newinp.erase(0, pos+1);
    //     // cout<<"gg "<<sub<<endl;
    // }
    // cout<<endl;
    int n;
    cin>>n;
    cout<<"fateen\n"<<n;

    return 0;
}